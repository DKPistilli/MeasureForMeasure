﻿using UnityEngine;
using System.Collections;

public class StartClefAnim : MonoBehaviour {

	public bool treble;

	private bool moving;

	private float time_delay = 0.5f;
	private float elapsed_time;

	private Vector3 treble_pos = new Vector3(-5.0f, 0.56f, 0f);
	private Vector3 bass_pos = new Vector3(-5.03f, -2.74f, 0f);

	private Rigidbody2D rb;
	

	void Start(){
		rb = gameObject.GetComponent<Rigidbody2D>();
		elapsed_time = 0f;
		moving = true;
	}

	
	// Update is called once per frame
	void Update () {
		if (moving){
			elapsed_time += Time.deltaTime;
			if (elapsed_time > time_delay){
				rb.velocity = new Vector3(3f, 0f, 0f);
			}
			if (treble){
				if (gameObject.transform.position.x >= treble_pos.x){
					moving = false;
					rb.velocity = Vector3.zero;
					gameObject.transform.position = treble_pos;
				}
			} else {
				if (gameObject.transform.position.x >= bass_pos.x){
					moving = false;
					rb.velocity = Vector3.zero;
					gameObject.transform.position = bass_pos;
				}
			}
		}
	}
}
