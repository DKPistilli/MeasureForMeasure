﻿using UnityEngine;
using System.Collections;

public class ScreenRes : MonoBehaviour {

	// Use this for initialization
	void Awake () {
		Screen.SetResolution (Screen.currentResolution.width, Screen.currentResolution.height, true);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
