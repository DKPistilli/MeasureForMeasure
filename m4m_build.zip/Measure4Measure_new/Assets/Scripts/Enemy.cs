﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Enemy : MonoBehaviour {

	public Rigidbody2D rb;
	public float speed;
	//private GameObject player;
	//private GameObject bass_player;
	private ScoreTracker script;
	//private GameObject scores;
	//private int num_scores = 10;


	// Use this for initialization
	void Start () {
		//scores = GameObject.Find("Canvas").gameObject;
		//player = GameObject.Find("Player");
		//bass_player = GameObject.Find("BassPlayer");
		script = ScoreTracker.instance;
		speed = -.5f - (script.level * .5f);
		rb = GetComponent<Rigidbody2D> ();
		rb.velocity = new Vector3(speed,0,0);
	}
	
	// Update is called once per frame
	void Update () {

	}

	void OnTriggerEnter2D(Collider2D other){
		if (other.tag == "TimeSignature"){
			Destroy(this.gameObject);
		}
	}

//	void OnTriggerEnter2D(Collider2D other){
//		if (other.name == "Player" || other.name == "BassPlayer") {
////			script.level = 1;
////			script.score = 0;
////			script.isDead = true; // STUB
////			scoreDisplay.text = "Measures Completed: " + script.score;
//			Destroy (player);
//			Destroy(bass_player);
//			HighScoreUpdate();
//			Destroy(scores);
//			Application.LoadLevel (0);
//
//		} 
//		else if(other.name != "Coin"){
//			Destroy (this.gameObject);
//		}
//	}

//	void HighScoreUpdate(){
//		int score = script.score;
//		int high_score;
//		int temp;
//		string high_score_key;
//		for (int i = 1; i <= num_scores; i++){
//			high_score_key = "HighScore" + i.ToString();
//			high_score = PlayerPrefs.GetInt(high_score_key, 0);
//
//			if (score >= high_score){
//				temp = high_score;
//				PlayerPrefs.SetInt(high_score_key, score);
//				score = temp;
//			}
//		}
//		PlayerPrefs.Save();
//	}
}
