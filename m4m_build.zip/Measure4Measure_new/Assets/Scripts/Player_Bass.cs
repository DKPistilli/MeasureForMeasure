﻿using UnityEngine;
using System.Collections;

public class Player_Bass : MonoBehaviour {

	private GameObject player;

	public bool tutorial;

	private GameObject bass_a;
	private GameObject bass_c;
	private GameObject bass_e;
	private GameObject bass_g;

	private GameObject current_key;

	private ScoreTracker score_tracker;

	private bool a_on;
	private bool c_on;
	private bool e_on;
	private bool g_on;
	
	private float a_time;
	private float c_time;
	private float e_time;
	private float g_time;
	
	private float key_live_time = .15f;

	private Animator anim;


	private bool moving_forward;
	private float move_time = 1f;
	private float elapsed_move_time;
	private Rigidbody2D rb;
	private SpriteRenderer sprite_renderer;

	public static Player_Bass instance = null;
	// Use this for initialization
	void Awake () {
		if (instance == null) {
			instance = this;
		} 
		else if (instance != this) {
			Destroy (gameObject);
		}
		DontDestroyOnLoad (gameObject);
	}
	// Use this for initialization
	void Start () {
		player = GameObject.Find("Player");
		anim = GetComponent<Animator> ();
		sprite_renderer = GetComponent<SpriteRenderer> ();

		score_tracker = GameObject.Find ("Treble_Cleff").GetComponent<ScoreTracker>();

		bass_a = GameObject.Find("Bass_A");
		bass_a.SetActive(false);
		bass_c = GameObject.Find("Bass_C");
		bass_c.SetActive(false);
		bass_e = GameObject.Find("Bass_E");
		bass_e.SetActive(false);
		bass_g = GameObject.Find("Bass_G");
		bass_g.SetActive(false);

		current_key = bass_a;
		current_key.SetActive(true);

		moving_forward = false;
		rb = gameObject.GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
		if (moving_forward){
			elapsed_move_time += Time.deltaTime;
			if (elapsed_move_time >= move_time || gameObject.transform.position.x >= 10f){
				rb.velocity = Vector3.zero;
				moving_forward = false;
				elapsed_move_time = 0f;
			}
		}
		if (a_on){
			a_time += Time.deltaTime;
			if (a_time >= key_live_time){
				a_time = 0f;
				bass_a.SetActive(false);
				a_on = false;
			}
		}
		if (c_on){
			c_time += Time.deltaTime;
			if (c_time >= key_live_time){
				c_time = 0f;
				bass_c.SetActive(false);
				c_on = false;
			}
		}
		if (e_on){
			e_time += Time.deltaTime;
			if (e_time >= key_live_time){
				e_time = 0f;
				bass_e.SetActive(false);
				e_on = false;
			}
		}
		if (g_on){
			g_time += Time.deltaTime;
			if (g_time >= key_live_time){
				g_time = 0f;
				bass_g.SetActive(false);
				g_on = false;
			}
		}
	}

	void OnTriggerEnter2D(Collider2D other){
		if (other.tag == "TimeSignature"){

			ParticleSystem bass_death = GameObject.Find("Red_bass").GetComponent<ParticleSystem>();
			bass_death.Play();
			AudioSource evil_laugh = GameObject.Find ("Evil_Laugh").GetComponent<AudioSource>();
			evil_laugh.Play();

			//if (player.activeInHierarchy){
			//	gameObject.SetActive(false);

			//} else {
				Destroy(player);
				sprite_renderer.enabled = false;
				GameObject trails = GameObject.Find ("Trailing_notes_bass");
				Destroy (trails); 
				StartCoroutine("endLevel");
			//}

		}
	}

	IEnumerator endLevel(){
		yield return new WaitForSeconds (3);
		score_tracker.ManualDestroy();
		if (score_tracker != null) {
			Destroy(score_tracker.gameObject);
		}
		Destroy(this.gameObject);
		TimeSignature.first_level = true;
		if (tutorial){
			Destroy (GameObject.Find ("Piano"));
			Piano.instance = null;
			Application.LoadLevel(Application.loadedLevel);
		} else {
			Application.LoadLevel ("HighScores");
		}
	}



	public void StartBassE(){
		current_key.SetActive(false);
		bass_e.SetActive(true);
		current_key = bass_e;
	}
	
	public void StartBassC(){
		current_key.SetActive(false);
		bass_c.SetActive(true);
		current_key = bass_c;
	}
	
	public void StartBassA(){
		current_key.SetActive(false);
		bass_a.SetActive(true);
		current_key = bass_a;
	}
	
	public void StartBassG(){
		current_key.SetActive(false);
		bass_g.SetActive(true);
		current_key = bass_g;
	}

	public void MoveForward(){
		rb.velocity = new Vector3(1f, 0f, 0f);
		moving_forward = true;
		anim.SetTrigger ("Booster");
		AudioSource Booster_Sound = GameObject.Find ("Booster_Sound").GetComponent<AudioSource>();
		Booster_Sound.Play();
		elapsed_move_time = 0f;
	}
}
