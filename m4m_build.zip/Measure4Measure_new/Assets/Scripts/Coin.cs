﻿using UnityEngine;
using System.Collections;

public class Coin : MonoBehaviour {


	public Rigidbody2D rb;
	private Player player_script;
	private Player_Bass bass_player_script;
	private ScoreTracker score_script;

	// Use this for initialization

	void Start () {
		score_script = ScoreTracker.instance;
		rb = gameObject.GetComponent<Rigidbody2D>();
		rb.velocity = new Vector3(-.5f - (score_script.level * .5f),0,0);

	}

	void OnTriggerEnter2D(Collider2D other){
		if (other.name == "Player"){
			player_script = Player.instance;
			player_script.MoveForward();
			Destroy(this.gameObject);
		}  else if (other.name == "BassPlayer"){
			bass_player_script = Player_Bass.instance;
			bass_player_script.MoveForward();
			Destroy(this.gameObject);

		}else Destroy(this.gameObject);
	}

	// Update is called once per frame
	void Update () {
	
	}
}
