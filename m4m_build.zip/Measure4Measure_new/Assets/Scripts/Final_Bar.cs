﻿using UnityEngine;
using System.Collections;

public class Final_Bar : MonoBehaviour {

	public Rigidbody2D rb;
	public float speed;
	private GameObject spawner;
	private ScoreTracker script;
	private SpawnEnemies spawn_script;

	
	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody2D> ();
		spawner = GameObject.Find("Treble_Cleff");
		script = ScoreTracker.instance;
		spawn_script = spawner.GetComponent<SpawnEnemies>();
		speed = -.5f - (script.level * .5f);
		rb.velocity = new Vector3(speed,0,0);
	}
	// Update is called once per frame
	void Update () {
		
	}
	
	void OnTriggerEnter2D(Collider2D other){
		if (other.name == "Player" || other.name == "BassPlayer"){
			Debug.Log("updating level counter");
			script.level++;
			spawn_script.spawn_time *= (speed) / (-.5f - (script.level * .5f));
			//want to load same level with positions of objects
			// all that changes is a saved score and updated speed
			Application.LoadLevel (Application.loadedLevel);
		} else {
			Destroy(other.gameObject);
		}
	}
}
