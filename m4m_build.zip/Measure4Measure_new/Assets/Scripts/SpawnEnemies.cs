﻿using UnityEngine;
using System.Collections;
using Random = UnityEngine.Random;

public class SpawnEnemies : MonoBehaviour {
	
	public GameObject[] enemies;
	public GameObject[] smalls;
	private Vector3[] treble_singles;
	private Vector3[] treble_doubles;
	private Vector3[] bass_singles;
	private Vector3[] bass_doubles;

	private bool[] treble_open;
	private bool[] bass_open;

	private int random_index;

	public float spawn_time;
	private float elapsed_time;
	private int max_rest;

	private GameObject final_bar;

	Vector3 TF = new Vector3(20f, 0f, 0f);
	Vector3 TA = new Vector3(20f, 0.5f, 0f);
	Vector3 TC = new Vector3(20f, 1f, 0f);
	Vector3 TE = new Vector3(20f, 1.5f, 0f);

	Vector3 TD1 = new Vector3(20f, .24f, 0f);
	Vector3 TD2 = new Vector3(20f, .74f, 0f);
	Vector3 TD3 = new Vector3(20f, 1.24f, 0f);


		
	Vector3 BG = new Vector3(20f, -2f, 0f);
	Vector3 BE = new Vector3(20f, -2.5f, 0f);
	Vector3 BC = new Vector3(20f, -3f, 0f);
	Vector3 BA = new Vector3(20f, -3.5f, 0f);

	Vector3 BD1 = new Vector3(20f, -2.24f, 0f);
	Vector3 BD2 = new Vector3(20f, -2.74f, 0f);
	Vector3 BD3 = new Vector3(20f, -3.24f, 0f);

	// Use this for initialization
	void Start () {
		treble_singles = new Vector3[4];
		treble_singles[0] = TF;
		treble_singles[1] = TA;
		treble_singles[2] = TC;
		treble_singles[3] = TE;

		treble_doubles = new Vector3[3];
		treble_doubles[0] = TD1;
		treble_doubles[1] = TD2;
		treble_doubles[2] = TD3;

		bass_singles = new Vector3[4];
		bass_singles[0] = BG;
		bass_singles[1] = BE;
		bass_singles[2] = BC;
		bass_singles[3] = BA;

		bass_doubles = new Vector3[3];
		bass_doubles[0] = BD1;
		bass_doubles[1] = BD2;
		bass_doubles[2] = BD3;

		treble_open = new bool[4];
		bass_open = new bool[4];

		for (int i = 0; i < 4; i++){
			treble_open[i] = true;
			bass_open[i] = true;
		}

		spawn_time = 4.0f;
		elapsed_time = 4.0f;
		max_rest = 2;
	}
	
	// Update is called once per frame
	void Update () {
		elapsed_time += Time.deltaTime;
		if (elapsed_time >= spawn_time){
			elapsed_time = 0f;
			final_bar = GameObject.Find("Final_Bar");
			if (final_bar.transform.position.x > TF.x){
				SpawnRandom(0);
			}
		}
	}

	void SpawnRandom(int num){
		GameObject to_spawn = enemies[Random.Range(0, enemies.Length)];
		if (to_spawn.name == "Eight_Rest" || to_spawn.name == "Quarter_Rest"){
			random_index = Random.Range(0, bass_doubles.Length);
			if (bass_open[random_index] && bass_open[random_index+1]){
				bass_open[random_index] = false;
				bass_open[random_index+1] = false;
				Instantiate(to_spawn, bass_doubles[random_index], Quaternion.identity);
			}
			random_index = Random.Range(0, treble_doubles.Length);
			if (treble_open[random_index] && treble_open[random_index+1]){
				treble_open[random_index] = false;
				treble_open[random_index+1] = false;
				Instantiate(to_spawn, treble_doubles[random_index], Quaternion.identity);
			}
			SpawnSmall(num + 2);
		}
		else {
			random_index = Random.Range(0, bass_singles.Length);
			if (bass_open[random_index]){
				bass_open[random_index] = false;
				Instantiate(to_spawn, bass_singles[random_index], Quaternion.identity);
			}
			random_index = Random.Range(0, treble_singles.Length);
			if (treble_open[random_index]){
				treble_open[random_index] = false;
				Instantiate(to_spawn, treble_singles[random_index], Quaternion.identity);
			}
			if (num >= 1){
				SpawnSmall(num + 1);
			} else {
				SpawnRandom (num + 1);
			}

		}
	}

	void SpawnSmall(int num){
		if (num >= max_rest){
			for (int i = 0; i < bass_open.Length; i++){
				bass_open[i] = true;
				treble_open[i] = true;
			}
			return;
		}
		else {
			GameObject to_spawn = enemies[Random.Range(0,smalls.Length)];
			random_index = Random.Range(0, bass_singles.Length);
			if (bass_open[random_index]){
				bass_open[random_index] = false;
				Instantiate(to_spawn, bass_singles[random_index], Quaternion.identity);
			}
			random_index = Random.Range(0, treble_singles.Length);
			if (treble_open[random_index]){
				treble_open[random_index] = false;
				Instantiate(to_spawn, treble_singles[random_index], Quaternion.identity);
			}
			SpawnSmall(num + 1);
		}
	}
}
