﻿using UnityEngine;
using System.Collections;

public class Menu : MonoBehaviour {

	private int num_scores = 10;

	// Use this for initialization
	void Start () {
		if (!PlayerPrefs.HasKey("HighScore1")){
			for (int i = 0; i <= num_scores ; i++){
				string score_key = "HighScore" + i.ToString();
				PlayerPrefs.SetInt(score_key, 0);
			}
			PlayerPrefs.Save();
		}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
