﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Player : MonoBehaviour {

	public float level = 1f;

	public bool tutorial;

	private GameObject bass_player;

	private GameObject treble_f;
	private GameObject treble_a;
	private GameObject treble_c;
	private GameObject treble_e;

	private GameObject current_key;

	private ScoreTracker score_tracker;

	private bool f_on;
	private bool a_on;
	private bool c_on;
	private bool e_on;

	private float f_time;
	private float a_time;
	private float c_time;
	private float e_time;

	private float key_live_time = .15f;

	private Animator anim;

	private bool moving_forward;
	private float move_time = 1f;
	private float elapsed_move_time;
	private Rigidbody2D rb;
	private SpriteRenderer sprite_renderer;
	
	public static Player instance = null;
	// Use this for initialization
	void Awake () {
		if (instance == null) {
			instance = this;
		} 
		else if (instance != this) {
			Destroy (gameObject);
		}
		DontDestroyOnLoad (gameObject);
	}

	void OnDestroy(){
	}

	void Start() {
		anim = GetComponent<Animator> (); 
		bass_player = GameObject.Find ("BassPlayer");

		score_tracker = GameObject.Find ("Treble_Cleff").GetComponent<ScoreTracker>();

		treble_f = GameObject.Find("Treble_F");
		treble_f.SetActive(false);
		treble_a = GameObject.Find("Treble_A");
		treble_a.SetActive(false);
		treble_c = GameObject.Find("Treble_C");
		treble_c.SetActive(false);
		treble_e = GameObject.Find("Treble_E");
		treble_e.SetActive(false);

		f_on = false;
		a_on = false;
		c_on = false;
		e_on = false;

		current_key = treble_f;
		current_key.SetActive(true);

		moving_forward = false;
		rb = gameObject.GetComponent<Rigidbody2D>();
		sprite_renderer = GetComponent<SpriteRenderer>();
	}
	
	// Update is called once per frame
	void Update () {
		if (moving_forward){
			elapsed_move_time += Time.deltaTime;
			if (elapsed_move_time >= move_time || gameObject.transform.position.x >= 10f){
				rb.velocity = Vector3.zero;
				moving_forward = false;
				elapsed_move_time = 0f;
			}
		}
		if (f_on){
			f_time +=
				Time.deltaTime;
			if (f_time >= key_live_time){
				treble_f.SetActive(false);
				f_on = false;
			}
		}
		if (a_on){
			a_time += Time.deltaTime;
			if (a_time >= key_live_time){
				treble_a.SetActive(false);
				a_on = false;
			}
		}
		if (c_on){
			c_time += Time.deltaTime;
			if (c_time >= key_live_time){
				treble_c.SetActive(false);
				c_on = false;
			}
		}
		if (e_on){
			e_time += Time.deltaTime;
			if (e_time >= key_live_time){
				treble_e.SetActive(false);
				e_on = false;
			}
		}
	}

	void OnTriggerEnter2D(Collider2D other){
		if (other.tag == "TimeSignature"){

			ParticleSystem treble_death = GameObject.Find("Red_treble").GetComponent<ParticleSystem>();
			treble_death.Play();
			AudioSource evil_laugh = GameObject.Find ("Evil_Laugh").GetComponent<AudioSource>();
			evil_laugh.Play();

			//if (bass_player.activeInHierarchy){
			//	gameObject.SetActive(false);
			//} else {

				Destroy(bass_player);
				sprite_renderer.enabled = false;
				GameObject trails = GameObject.Find ("Trailing_notes");
				Destroy (trails); 
				StartCoroutine("endLevel");
			//}
		}
	}

	IEnumerator endLevel(){
		yield return new WaitForSeconds (3);
		score_tracker.ManualDestroy();
		if (score_tracker != null) {
			Destroy(score_tracker.gameObject);
		}

		Destroy(this.gameObject);
		TimeSignature.first_level = true;
		if (tutorial){
			Destroy (GameObject.Find ("Piano"));
			Piano.instance = null;
			Application.LoadLevel(Application.loadedLevel);
		} else {
			Application.LoadLevel ("HighScores");
		}
	}



	public void StartTrebleF(){
		current_key.SetActive(false);
		treble_f.SetActive(true);
		current_key = treble_f;
	}

	public void StartTrebleA(){
		current_key.SetActive(false);
		treble_a.SetActive(true);
		current_key = treble_a;
	}

	public void StartTrebleC(){
		current_key.SetActive(false);
		treble_c.SetActive(true);
		current_key = treble_c;
	}

	public void StartTrebleE(){
		current_key.SetActive(false);
		treble_e.SetActive(true);
		current_key = treble_e;
	}

	public void MoveForward(){
		rb.velocity = new Vector3(1f, 0f, 0f);
		moving_forward = true;
		anim.SetTrigger ("Booster");
		AudioSource Booster_Sound = GameObject.Find ("Booster_Sound").GetComponent<AudioSource>();
		Booster_Sound.Play();
		elapsed_move_time = 0f;
	}

}
