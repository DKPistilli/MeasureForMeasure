﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(AudioSource))]

public class ChangeLanes : MonoBehaviour {

	public bool gamePaused = false; //TYLER CODE

	public bool in_bass;

	public bool bass_destroyed;
	public bool treble_destoryed;

	private Player player_script;
	private Player_Bass bass_player_script;
	private SpriteRenderer trailing_notes;
	private SpriteRenderer trailing_notes_bass;

	private Rigidbody2D rb;

	Vector3 TF = new Vector3(0f, 0f, 0f);
	Vector3 TA = new Vector3(0f, 0.5f, 0f);
	Vector3 TC = new Vector3(0f, 1f, 0f);
	Vector3 TE = new Vector3(0f, 1.5f, 0f);

	Vector3 BG = new Vector3(0f, -2f, 0f);
	Vector3 BE = new Vector3(0f, -2.5f, 0f);
	Vector3 BC = new Vector3(0f, -3f, 0f);
	Vector3 BA = new Vector3(0f, -3.5f, 0f);

	private Color lightBlue = new Vector4 (0f, 202/255f, 255/255f, 255/255f);
	private Color yellow = new Vector4 (241/255f, 255/255f, 0f, 255/255f);
	private Color red = new Vector4 (255/255f, 0f, 0f, 255/255f);
	private Color orange = new Vector4 (255/255f, 153/255f, 0f, 255/255f);
	private Color green = new Vector4 (0f, 255/255f, 12/255f, 255/255f);
	private Color maroon = new Vector4 (174/255f, 0f, 0f, 255/255f);
	private Color pink = new Vector4 (255/255f, 0f, 227/255f, 255/255f);
	private Color blue = new Vector4 (72/255f, 0f, 255/255f, 255/255f);




	void OnLevelWasLoaded(int level){
	}

	void Start () {
		player_script = GameObject.Find("Player").GetComponent<Player>();
		bass_player_script = GameObject.Find ("BassPlayer").GetComponent<Player_Bass>();
		trailing_notes = GameObject.Find ("Trailing_notes").GetComponent<SpriteRenderer> ();
		trailing_notes_bass = GameObject.Find ("Trailing_notes_bass").GetComponent<SpriteRenderer> ();

		rb = gameObject.GetComponent<Rigidbody2D>();

	}
	

	void Update () {

		//TYLER CODE
		if (Input.GetKeyDown (KeyCode.Escape)) {
			if(gamePaused){
				gamePaused = false;
				Time.timeScale = 1.0f;
			}	
			else {
				gamePaused = true;
				Time.timeScale = 0.0f;
			}
		}

		if (!in_bass) {
			if (Input.GetKeyDown (KeyCode.J)) {
				player_script.StartTrebleF();
				gameObject.transform.position = new Vector3(gameObject.transform.position.x, TF.y, 0f);
				trailing_notes.color = green;
				if (rb.velocity.x < 0f){
					rb.velocity = Vector3.zero;
				}
			} else if (Input.GetKeyDown (KeyCode.K)) {
				player_script.StartTrebleA();
				gameObject.transform.position = new Vector3(gameObject.transform.position.x, TA.y, 0f);
				trailing_notes.color = maroon;
				if (rb.velocity.x < 0f){
					rb.velocity = Vector3.zero;
				}			
			} else if (Input.GetKeyDown (KeyCode.L)) {
				player_script.StartTrebleC();
				gameObject.transform.position = new Vector3(gameObject.transform.position.x, TC.y, 0f);
				trailing_notes.color = pink;
				if (rb.velocity.x < 0f){
					rb.velocity = Vector3.zero;
				}			
			} else if (Input.GetKeyDown (KeyCode.Semicolon)) {
				player_script.StartTrebleE();
				gameObject.transform.position = new Vector3(gameObject.transform.position.x, TE.y, 0f);
				trailing_notes.color = blue;
				if (rb.velocity.x < 0f){
					rb.velocity = Vector3.zero;
				}			
			}
		}
		else {
			if (Input.GetKeyDown (KeyCode.F)) {
				bass_player_script.StartBassG();
				gameObject.transform.position = new Vector3(gameObject.transform.position.x, BG.y, 0f);
				trailing_notes_bass.color = orange;
				if (rb.velocity.x < 0f){
					rb.velocity = Vector3.zero;
				}			
			} else if (Input.GetKeyDown (KeyCode.A)) {
				bass_player_script.StartBassA();
				gameObject.transform.position = new Vector3(gameObject.transform.position.x, BA.y, 0f);
				trailing_notes_bass.color = lightBlue;
				if (rb.velocity.x < 0f){
					rb.velocity = Vector3.zero;
				}			
			} else if (Input.GetKeyDown (KeyCode.S)) {
				bass_player_script.StartBassC();
				gameObject.transform.position = new Vector3(gameObject.transform.position.x, BC.y, 0f);
				trailing_notes_bass.color = yellow;
				if (rb.velocity.x < 0f){
					rb.velocity = Vector3.zero;
				}			
			} else if (Input.GetKeyDown (KeyCode.D)) {
				bass_player_script.StartBassE();
				gameObject.transform.position = new Vector3(gameObject.transform.position.x, BE.y, 0f);
				trailing_notes_bass.color = red;
				if (rb.velocity.x < 0f){
					rb.velocity = Vector3.zero;
				}			
			}
		}
	}
}
