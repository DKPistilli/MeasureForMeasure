﻿using UnityEngine;
using System.Collections;

public class PowerUps : MonoBehaviour {

	public Rigidbody2D rb;
	private ScoreTracker score_script;
	private Crescendo cresc;

	public int fill_amount;
	
	// Use this for initialization
	
	void Start () {
		score_script = ScoreTracker.instance;
		rb = gameObject.GetComponent<Rigidbody2D>();
		cresc = Crescendo.instance;
		rb.velocity = new Vector3(-.5f - (score_script.level * .5f),0,0);
		
	}
	
	void OnTriggerEnter2D(Collider2D other){
		if (other.name == "Player"){
			cresc.IncreaseFill(fill_amount);
			PlaySound();
			Destroy(this.gameObject);
		}  else if (other.name == "BassPlayer"){
			cresc.IncreaseFill(fill_amount);
			PlaySound();
			Destroy(this.gameObject);
			
		}else Destroy(this.gameObject);
	}

	void PlaySound(){
		AudioSource Sound;
		if (fill_amount == 1) {
			Sound = GameObject.Find("p_sound").GetComponent<AudioSource>();
		} else if (fill_amount == 2) {
			Sound = GameObject.Find("mp_sound").GetComponent<AudioSource>();
		} else {
			Sound = GameObject.Find("f_sound").GetComponent<AudioSource>();
		}
		Sound.Play();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
