﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Instructions : MonoBehaviour {

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.RightArrow)){
			//instruction++;
			Debug.Log("right arrow pressed!");
			NextInstruction();
		} else if (Input.GetKeyDown(KeyCode.LeftArrow)){
			Debug.Log("left arrow pressed!");
			PrevInstruction();
		}
	}

	void NextInstruction(){
		Object[] objects = GameObject.FindObjectsOfType(typeof(GameObject));
		for (int i = 0; i < objects.Length; i++){
			if (objects[i].name != "Menu_music")
				Destroy(objects[i]);
		}
		Player_Bass.instance = null;
		Player.instance = null;
		if (Application.loadedLevel == 7) {
			GameObject men_music = GameObject.Find("Menu_music");
			if (men_music != null){
				Menu_music music_script = men_music.GetComponent<Menu_music>();
				music_script.DestroyMusic();
			}
		}

		Application.LoadLevel(Application.loadedLevel + 1);
	}

	void PrevInstruction(){
		Object[] objects = GameObject.FindObjectsOfType(typeof(GameObject));
		for (int i = 0; i < objects.Length; i++){
			if (objects[i].name != "Menu_music")
				Destroy(objects[i]);
		}
		Player_Bass.instance = null;
		Player.instance = null;
		if (Application.loadedLevel == 2){
			Application.LoadLevel(0);
		} else {
			Application.LoadLevel(Application.loadedLevel - 1);
		}
	}
}
