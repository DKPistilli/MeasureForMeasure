﻿using UnityEngine;
using System.Collections;

public class TimeSignature : MonoBehaviour {
	public bool up;

	public static bool first_level = true;

	private Rigidbody2D rb;
	private float elapsed_time;
	private float max_time = 3.5f;

	void Awake(){
		if (!first_level) {
			Destroy(gameObject);
		}
	}

	// Use this for initialization
	void Start () {
		rb = gameObject.GetComponent<Rigidbody2D>();
		elapsed_time = 0f;
		first_level = false;

	}
	
	// Update is called once per frame
	void Update () {
		elapsed_time += Time.deltaTime;
		if (elapsed_time > 0.5f){
			if (up){
				rb.velocity = new Vector3(0f, 2f, 0f);
			} else {
				rb.velocity = new Vector3(0f, -2f, 0f);
			}
			if (elapsed_time > max_time){
				Destroy(gameObject);
			}
		}
	
	}

}
