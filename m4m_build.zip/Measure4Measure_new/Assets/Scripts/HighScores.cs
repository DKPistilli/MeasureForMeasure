﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class HighScores : MonoBehaviour {

	private Text scores;
	private int num_scores = 10;
	private Text name_input;
	// Use this for initialization
	void Start () {
		Debug.Log(PlayerPrefs.GetInt("CurrentScore", 0));
		//PlayerPrefs.DeleteAll();
		string score_key = "HighScore";
		string name_key = "HighScoreName";
		scores = GameObject.Find ("High_Scores").GetComponent<Text>();
		for (int i = 1; i <= num_scores; i++){
			string score_string = PlayerPrefs.GetInt(score_key + i.ToString()).ToString();
			string name_string = PlayerPrefs.GetString(name_key + i.ToString());
			scores.text += i.ToString() + ".) " + name_string + ": " + score_string + "\n";
		}
		name_input = GameObject.Find ("NameText").GetComponent<Text>();
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKey(KeyCode.RightArrow)){
			GameObject men_music = GameObject.Find("Menu_music");
			if (men_music != null){
				Menu_music music_script = men_music.GetComponent<Menu_music>();
				music_script.DestroyMusic();
			}
			Application.LoadLevel("MainGame");
		} else if (Input.GetKey (KeyCode.Escape)){
			GameObject men_music = GameObject.Find("Menu_music");
			if (men_music != null){
				Menu_music music_script = men_music.GetComponent<Menu_music>();
				music_script.DestroyMusic();
			}// TYLER CODE
			Application.LoadLevel("Menu");
		}
	}

	public void HighScoreUpdate(){
		
		int temp_score = PlayerPrefs.GetInt("CurrentScore", 0);
		PlayerPrefs.DeleteKey("CurrentScore");
		string temp_name = name_input.text, high_name, temp_n;
		int high_score;
		int temp_s;
		string high_score_key, high_score_name;
		for (int i = 1; i <= num_scores; i++){
			high_score_key = "HighScore" + i.ToString();
			high_score_name = "HighScoreName" + i.ToString();
			high_score = PlayerPrefs.GetInt(high_score_key, 0);
			high_name = PlayerPrefs.GetString(high_score_name, "");
			
			if (temp_score >= high_score){
				temp_s = high_score;
				temp_n = high_name;
				PlayerPrefs.SetInt(high_score_key, temp_score);
				PlayerPrefs.SetString(high_score_name, temp_name);
				temp_score = temp_s;
				temp_name = temp_n;
			}
		}
		PlayerPrefs.Save();
		ChangeScores();
	}

	void ChangeScores(){
		string score_key = "HighScore";
		string name_key = "HighScoreName";
		scores.text = "High Scores: \n\n";
		for (int i = 1; i <= num_scores; i++){
			string score_string = PlayerPrefs.GetInt(score_key + i.ToString()).ToString();
			string name_string = PlayerPrefs.GetString(name_key + i.ToString());
			scores.text += i.ToString() + ".) " + name_string + ": " + score_string + "\n";
		}
	}
}
