﻿using UnityEngine;
using System.Collections;

public class Measures : MonoBehaviour {

	public Rigidbody2D rb;
	public float speed;
	public bool tutorial;
	//private GameObject player;
	//private Player script;

	private ScoreTracker score_tracker;
	
	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody2D> ();
		//player = GameObject.Find("Player");
		score_tracker = GameObject.Find ("Treble_Cleff").GetComponent<ScoreTracker>();
		speed = -.5f - (score_tracker.level * .5f);
		rb.velocity = new Vector3(speed,0,0);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	
	void OnTriggerEnter2D(Collider2D other){
		if (other.name == "Player" || other.name == "BassPlayer") {
			if (!tutorial){
				score_tracker.updateScore ();
			}
				
		} 
		else if (other.name == "Treble_Cleff" || other.name == "Bass_Cleff"){
			Destroy (this.gameObject);
		}
	}
}
