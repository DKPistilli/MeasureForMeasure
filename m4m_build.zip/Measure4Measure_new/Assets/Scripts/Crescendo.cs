﻿using UnityEngine;
using System.Collections;

public class Crescendo : MonoBehaviour {

	private SpriteRenderer sprite;
	private Animator anim;

	public GameObject super_crescendo;

	public Sprite[] sprites;

	public int fill;
	private int max_fill = 8;

	private float destroy_x_coord = 15f;

	private Rigidbody2D rb;
	private Collider2D coll;
	
	public static Crescendo instance = null;
	// Use this for initialization
	void Awake () {
		if (instance == null) {
			instance = this;
		} 
		else if (instance != this) {
			Destroy (gameObject);
		}
		DontDestroyOnLoad (gameObject);
	}

	// Use this for initialization
	void Start () {
		sprite = gameObject.GetComponent<SpriteRenderer> ();
		anim = gameObject.GetComponent<Animator> ();
		Debug.Log (anim);
		anim.enabled = false;


	
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.Space) && fill == max_fill) {
			GameObject cresc = GameObject.Find("SuperCrescendo");
			Destroy(cresc);
			Instantiate(super_crescendo);

			GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");
			GameObject[] particles = GameObject.FindGameObjectsWithTag("Crescendo");
			Debug.Log ("particle systems: " + particles.Length.ToString());
			ParticleSystem p;
			AudioSource Sound = GameObject.Find ("SuperCrescendo_Sound").GetComponent<AudioSource>();
			Sound.Play ();
			for (int i = 0; i < particles.Length; i++){
				p = particles[i].GetComponent<ParticleSystem>();
				Debug.Log(p.isPlaying);
				if(p.isPlaying){
					p.Stop ();
					p.Clear ();
				}
				p.time = 0;
				p.Play ();
			}
			for (int i = 0; i < enemies.Length; i++){
				if (enemies[i].transform.position.x < destroy_x_coord){
					rb = enemies[i].gameObject.GetComponent<Rigidbody2D>();
					coll = enemies[i].gameObject.GetComponent<Collider2D>();
					rb.velocity = new Vector3(0f, 0f, 0f);
					coll.isTrigger = true;
					rb.isKinematic = false;
					rb.gravityScale = -1.5f;
				}
				ExpendCrescendo();
				GameObject temp = GameObject.Find ("Player");
				Rigidbody2D rb_temp;
				if (temp != null){
					rb_temp = temp.GetComponent<Rigidbody2D>();
					if (rb_temp.velocity.x < 0f){
						rb_temp.velocity = Vector3.zero;
					}
				}

				temp = GameObject.Find("BassPlayer");
				if (temp != null){
					rb_temp = temp.GetComponent<Rigidbody2D>();
					if (rb_temp.velocity.x < 0f){
						rb_temp.velocity = Vector3.zero;
					}
				}

			}
		}
	}

	public void IncreaseFill(int amount){
		if (amount + fill > max_fill){
			fill = 8;
		} else {
			fill += amount;
		}
		updateSprite ();
	}

	public void ExpendCrescendo(){
		fill = 0;
		anim.enabled = false;
		updateSprite ();
	}

	void updateSprite(){
		if (fill == 8) {
			anim.enabled = true;		
		} else {
			sprite.sprite = sprites[fill];
		}
	}


}
