﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class ScoreTracker : MonoBehaviour {

	public int score = 0;
	public float level = 1f;

	private Text scoreDisplay;
	private Text high_score_display;

	private GameObject scores;
	private GameObject piano;
	private GameObject bass_clef;
	private GameObject crescendo;

	public static ScoreTracker instance = null;

	void Awake(){
		if (instance == null) {
			instance = this;
		} 
		else if (instance != this) {
			Destroy (gameObject);
		}
		DontDestroyOnLoad(gameObject);
	}

	public void ManualDestroy(){
		Destroy (piano);
		Destroy (scores);
		Destroy(bass_clef);
		Destroy (crescendo);
		PlayerPrefs.SetInt("CurrentScore", score);
	}
	// Use this for initialization
	void Start () {
		piano = GameObject.Find ("Piano");
		bass_clef = GameObject.Find ("Bass_Cleff");
		scores = GameObject.Find("Canvas").gameObject;
		crescendo = GameObject.Find ("Crescendo");
		scoreDisplay = GameObject.Find ("Score_Display").GetComponent<Text>();
		high_score_display = GameObject.Find("High_Score_Display").GetComponent<Text>();
		high_score_display.text = "High Score: " + PlayerPrefs.GetInt("HighScore1").ToString();
		scoreDisplay.text = "Measures Completed: " + score.ToString();
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void updateScore () {
		score++;
		scoreDisplay.text = "Measures Completed: " + score.ToString();
	}
}
