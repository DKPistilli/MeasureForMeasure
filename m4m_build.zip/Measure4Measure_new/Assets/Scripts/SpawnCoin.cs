﻿using UnityEngine;
using System.Collections;

public class SpawnCoin : MonoBehaviour {

	public float spawn_time;
	private float elapsed_time;
	private Vector3[] spawn_positions;

	private GameObject final_bar;
	public GameObject[] coins;

	Vector3 TF = new Vector3(20f, 0f, 0f);
	Vector3 TA = new Vector3(20f, 0.5f, 0f);
	Vector3 TC = new Vector3(20f, 1f, 0f);
	Vector3 TE = new Vector3(20f, 1.5f, 0f);
	
	Vector3 BG = new Vector3(20f, -2f, 0f);
	Vector3 BE = new Vector3(20f, -2.5f, 0f);
	Vector3 BC = new Vector3(20f, -3f, 0f);
	Vector3 BA = new Vector3(20f, -3.5f, 0f);

	// Use this for initialization
	void Start () {
		spawn_positions = new Vector3[8];
		spawn_positions[0] = TF;
		spawn_positions[1] = TA;
		spawn_positions[2] = TC;
		spawn_positions[3] = TE;
		spawn_positions[4] = BG;
		spawn_positions[5] = BE;
		spawn_positions[6] = BC;
		spawn_positions[7] = BA;
		elapsed_time = 0f;
	}
	
	// Update is called once per frame
	void Update () {
		elapsed_time += Time.deltaTime;
		if (elapsed_time >= spawn_time){
			elapsed_time = 0;
			final_bar = GameObject.Find("Final_Bar");
			if (final_bar.transform.position.x > TF.x){
				Vector3 spawn_pos = spawn_positions[Random.Range(0, spawn_positions.Length)];
				int spawn_no = Random.Range(0, coins.Length);
				Instantiate(coins[spawn_no], spawn_pos, Quaternion.identity);
			}
		}
	
	}
}
